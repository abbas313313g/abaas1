// Function to get user's current location
export const getUserLocation = (): Promise<{latitude: number; longitude: number}> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        reject(error);
      }
    );
  });
};

// Function to get address from coordinates using reverse geocoding
export const getAddressFromCoordinates = async (latitude: number, longitude: number): Promise<string> => {
  try {
    // Using Nominatim API for reverse geocoding (OpenStreetMap)
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&accept-language=ar`
    );
    const data = await response.json();
    
    if (data && data.display_name) {
      return data.display_name;
    } else {
      return `${latitude}, ${longitude}`;
    }
  } catch (error) {
    console.error("Error fetching address:", error);
    return `${latitude}, ${longitude}`;
  }
};