import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, CartItem, Product, Category, Restaurant } from './types';
import { categories, products, restaurants } from './data';

interface StoreState {
  user: User | null;
  isAuthenticated: boolean;
  cart: CartItem[];
  currentLocation: {
    latitude: number;
    longitude: number;
    address: string;
  } | null;
  language: 'en' | 'ar';
  categories: Category[];
  products: Product[];
  restaurants: Restaurant[];
  
  // Auth actions
  login: (user: User) => void;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
  
  // Cart actions
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartItemQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Location actions
  setCurrentLocation: (location: { latitude: number; longitude: number; address: string }) => void;
  trackUserLocation: () => void;
  
  // Language actions
  setLanguage: (language: 'en' | 'ar') => void;
}

// Function to calculate distance between two coordinates in kilometers
export const calculateDistance = (
  lat1: number, 
  lon1: number, 
  lat2: number, 
  lon2: number
): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const distance = R * c; // Distance in km
  return distance;
};

const deg2rad = (deg: number): number => {
  return deg * (Math.PI/180);
};

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      cart: [],
      currentLocation: null,
      language: 'ar', // Default to Arabic
      categories,
      products,
      restaurants,

      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      updateUser: (userData) => set((state) => ({
        user: state.user ? { ...state.user, ...userData } : null
      })),

      addToCart: (product, quantity = 1) => set((state) => {
        const existingItemIndex = state.cart.findIndex(
          (item) => item.product.id === product.id
        );

        if (existingItemIndex !== -1) {
          // Product already exists in cart, update quantity
          const newCart = [...state.cart];
          newCart[existingItemIndex].quantity += quantity;
          return { cart: newCart };
        } else {
          // Add new product to cart
          return { cart: [...state.cart, { product, quantity }] };
        }
      }),

      removeFromCart: (productId) => set((state) => ({
        cart: state.cart.filter((item) => item.product.id !== productId)
      })),

      updateCartItemQuantity: (productId, quantity) => set((state) => ({
        cart: state.cart.map((item) =>
          item.product.id === productId
            ? { ...item, quantity: Math.max(1, quantity) }
            : item
        )
      })),

      clearCart: () => set({ cart: [] }),

      setCurrentLocation: (location) => set({ currentLocation: location }),
      
      trackUserLocation: () => {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            async (position) => {
              try {
                const { latitude, longitude } = position.coords;
                
                // Attempt to get address using reverse geocoding
                let address = "موقعك الحالي";
                try {
                  const response = await fetch(
                    `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&accept-language=ar`
                  );
                  const data = await response.json();
                  if (data.display_name) {
                    address = data.display_name;
                  }
                } catch (error) {
                  console.error("Error getting address:", error);
                }
                
                set({ 
                  currentLocation: { 
                    latitude, 
                    longitude, 
                    address 
                  } 
                });
              } catch (error) {
                console.error("Error tracking location:", error);
              }
            },
            (error) => {
              console.error("Geolocation error:", error);
              alert("تعذر الوصول إلى موقعك. يرجى السماح بالوصول للموقع واعادة المحاولة.");
            }
          );
        } else {
          alert("متصفحك لا يدعم تحديد الموقع.");
        }
      },
      
      setLanguage: (language) => set({ language })
    }),
    {
      name: 'store'
    }
  )
);