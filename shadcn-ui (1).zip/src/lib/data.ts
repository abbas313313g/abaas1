import { Category, Product, Restaurant } from './types';

// Sample Categories
export const categories: Category[] = [
  {
    id: '1',
    name: 'وجبات سريعة',
    image: '/assets/categories/fast-food.jpg',
    productCount: 15
  },
  {
    id: '2',
    name: 'مشروبات',
    image: '/assets/categories/drinks.jpg',
    productCount: 8
  },
  {
    id: '3',
    name: 'حلويات',
    image: '/assets/categories/desserts.jpg',
    productCount: 10
  },
  {
    id: '4',
    name: 'مأكولات صحية',
    image: '/assets/categories/healthy.jpg',
    productCount: 12
  },
  {
    id: '5',
    name: 'مأكولات شرقية',
    image: '/assets/categories/oriental.jpg',
    productCount: 18
  },
  {
    id: '6',
    name: 'مأكولات إيطالية',
    image: '/assets/categories/italian.jpg',
    productCount: 9
  }
];

// Sample Restaurants
export const restaurants: Restaurant[] = [
  {
    id: '1',
    name: 'مطعم الشرق',
    image: '/assets/restaurants/restaurant1.jpg',
    rating: 4.8,
    deliveryTime: '30-45 دقيقة',
    location: {
      latitude: 33.3152,
      longitude: 44.3661
    }
  },
  {
    id: '2',
    name: 'برجر هاوس',
    image: '/assets/restaurants/restaurant2.jpg',
    rating: 4.5,
    deliveryTime: '20-30 دقيقة',
    location: {
      latitude: 33.3201,
      longitude: 44.3785
    }
  },
  {
    id: '3',
    name: 'بيتزا بلازا',
    image: '/assets/restaurants/restaurant3.jpg',
    rating: 4.2,
    deliveryTime: '30-40 دقيقة',
    location: {
      latitude: 33.3091,
      longitude: 44.3811
    }
  },
  {
    id: '4',
    name: 'سويت كافيه',
    image: '/assets/restaurants/restaurant4.jpg',
    rating: 4.7,
    deliveryTime: '15-25 دقيقة'
  },
  {
    id: '5',
    name: 'أطيب المأكولات',
    image: '/assets/restaurants/restaurant5.jpg',
    rating: 4.3,
    deliveryTime: '35-45 دقيقة',
    location: {
      latitude: 33.3242,
      longitude: 44.3701
    }
  },
  {
    id: '6',
    name: 'فريش فود',
    image: '/assets/restaurants/restaurant6.jpg',
    rating: 4.4,
    deliveryTime: '25-35 دقيقة'
  }
];

// Sample Products
export const products: Product[] = [
  {
    id: '1',
    name: 'برجر لحم مشوي',
    description: 'برجر لحم بقري مشوي مع صلصة خاصة وخضروات طازجة',
    price: 7500,
    image: '/assets/products/product1.jpg',
    category: '1',
    restaurant: 'برجر هاوس',
    discount: 0,
    location: {
      latitude: 33.3201,
      longitude: 44.3785
    }
  },
  {
    id: '2',
    name: 'بيتزا مارجريتا',
    description: 'بيتزا إيطالية أصلية مع صلصة طماطم وجبنة موزاريلا',
    price: 12000,
    image: '/assets/products/product2.jpg',
    category: '6',
    restaurant: 'بيتزا بلازا',
    discount: 10,
    location: {
      latitude: 33.3091,
      longitude: 44.3811
    }
  },
  {
    id: '3',
    name: 'كوكتيل فواكه طازجة',
    description: 'مزيج من الفواكه الموسمية الطازجة',
    price: 4500,
    image: '/assets/products/product3.jpg',
    category: '2',
    restaurant: 'سويت كافيه',
    discount: 0
  },
  {
    id: '4',
    name: 'كبة موصلية',
    description: 'كبة موصلية تقليدية مع مرق خاص',
    price: 8000,
    image: '/assets/products/product4.jpg',
    category: '5',
    restaurant: 'مطعم الشرق',
    discount: 0,
    location: {
      latitude: 33.3152,
      longitude: 44.3661
    }
  },
  {
    id: '5',
    name: 'سلطة يونانية',
    description: 'سلطة صحية مع جبن الفيتا والزيتون',
    price: 6000,
    image: '/assets/products/product5.jpg',
    category: '4',
    restaurant: 'فريش فود',
    discount: 15
  },
  {
    id: '6',
    name: 'كنافة بالجبن',
    description: 'حلوى شرقية تقليدية محشوة بالجبن والقطر',
    price: 5500,
    image: '/assets/products/product6.jpg',
    category: '3',
    restaurant: 'سويت كافيه',
    discount: 0
  },
  {
    id: '7',
    name: 'شاورما دجاج',
    description: 'شاورما دجاج مع صلصة ثوم وخضروات',
    price: 6500,
    image: '/assets/products/product7.jpg',
    category: '5',
    restaurant: 'أطيب المأكولات',
    discount: 0,
    location: {
      latitude: 33.3242,
      longitude: 44.3701
    }
  },
  {
    id: '8',
    name: 'آيس كريم بالفستق',
    description: 'آيس كريم بالفستق الحلبي والكريمة',
    price: 4000,
    image: '/assets/products/product8.jpg',
    category: '3',
    restaurant: 'سويت كافيه',
    discount: 0
  }
];

// Function to get products by category name
export function getProductsByCategory(categoryName: string): Product[] {
  const categoryId = categories.find(c => c.name === categoryName)?.id;
  if (!categoryId) return [];
  return products.filter(product => product.category === categoryId);
}