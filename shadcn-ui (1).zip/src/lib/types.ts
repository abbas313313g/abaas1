// User types
export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  profileImage?: string;
  addresses?: UserAddress[];
}

export interface UserAddress {
  id: string;
  title: string;
  fullAddress: string;
  isDefault: boolean;
  location?: {
    latitude: number;
    longitude: number;
  };
}

// Product types
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  discount: number;
  restaurant?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

// Category types
export interface Category {
  id: string;
  name: string;
  image: string;
  productCount: number;
}

// Restaurant types
export interface Restaurant {
  id: string;
  name: string;
  image: string;
  rating: number;
  deliveryTime: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  distance?: number;
}

// Cart types
export interface CartItem {
  product: Product;
  quantity: number;
}

// Order types
export interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  status: OrderStatus;
  total: number;
  createdAt: string;
  deliveryAddress: UserAddress;
  paymentMethod: PaymentMethod;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'delivering' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cash' | 'card' | 'wallet';