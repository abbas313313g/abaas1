interface TelegramMessage {
  chat_id: string;
  text: string;
  parse_mode?: string;
}

export async function sendTelegramMessage(message: string): Promise<boolean> {
  try {
    const BOT_TOKEN = "7601214758:AAFtkJRGqffuDLKPb8wuHm7r0pt_pDE7BSE";
    const CHAT_ID = "6626221973";
    
    const telegramMessage: TelegramMessage = {
      chat_id: CHAT_ID,
      text: message,
      parse_mode: "HTML"
    };
    
    const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(telegramMessage)
    });
    
    const data = await response.json();
    return data.ok;
  } catch (error) {
    console.error("Error sending Telegram message:", error);
    return false;
  }
}

export function formatOrderForTelegram(order: any, user: any): string {
  // Format the order details for Telegram
  let message = `<b>🛍️ طلب جديد #${order.id.slice(0, 8)}</b>\n\n`;
  
  // Add customer info
  message += `<b>معلومات الزبون:</b>\n`;
  message += `الاسم: ${user.name}\n`;
  message += `الهاتف: ${user.phone}\n`;
  message += `الموقع: ${user.location?.address || 'غير محدد'}\n\n`;
  
  // Add order items
  message += `<b>المنتجات:</b>\n`;
  order.items.forEach((item: any, index: number) => {
    message += `${index + 1}. ${item.quantity} × ${item.product.name} - ${formatPrice(item.product.price * item.quantity)} د.ع\n`;
  });
  
  message += `\n<b>رسوم التوصيل:</b> ${formatPrice(order.deliveryFee)} د.ع (${order.distance.toFixed(1)} كم)`;
  message += `\n<b>المجموع الكلي:</b> ${formatPrice(order.totalPrice)} د.ع`;
  
  message += `\n\nتاريخ الطلب: ${new Date(order.createdAt).toLocaleString()}`;
  
  return message;
}

function formatPrice(price: number): string {
  return new Intl.NumberFormat('ar-IQ', {
    style: 'decimal',
    maximumFractionDigits: 0,
  }).format(price);
}