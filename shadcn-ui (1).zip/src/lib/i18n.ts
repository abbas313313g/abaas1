export const translations = {
  en: {
    // Header
    home: "Home",
    categories: "Categories",
    cart: "Cart",
    profile: "Profile",
    login: "Login / Register",
    search: "Search",
    
    // Footer
    about: "About Us",
    contact: "Contact",
    terms: "Terms & Conditions",
    privacy: "Privacy Policy",
    
    // Auth
    loginTitle: "Login",
    registerTitle: "Register",
    email: "Email",
    password: "Password",
    name: "Full Name",
    confirmPassword: "Confirm Password",
    loginButton: "Login",
    registerButton: "Register",
    forgotPassword: "Forgot Password?",
    noAccount: "Don't have an account?",
    hasAccount: "Already have an account?",
    
    // Cart
    cartTitle: "Shopping Cart",
    emptyCart: "Your cart is empty",
    continueShopping: "Continue Shopping",
    checkout: "Checkout",
    total: "Total",
    remove: "Remove",
    
    // Product
    addToCart: "Add to Cart",
    quantity: "Quantity",
    description: "Description",
    specifications: "Specifications",
    reviews: "Reviews",
    price: "Price",
    
    // Location
    currentLocation: "Current Location",
    updateLocation: "Update Location",
    locationPermission: "Allow location access",
    locationDistance: "Distance",
    
    // Orders
    orders: "Orders",
    orderHistory: "Order History",
    orderDetails: "Order Details",
    orderDate: "Order Date",
    orderStatus: "Status",
    orderTotal: "Total",
    
    // Misc
    loading: "Loading...",
    error: "Something went wrong",
    success: "Success!",
    confirm: "Confirm",
    cancel: "Cancel",
  },
  ar: {
    // Header
    home: "الرئيسية",
    categories: "الفئات",
    cart: "عربة التسوق",
    profile: "الملف الشخصي",
    login: "تسجيل الدخول / التسجيل",
    search: "بحث",
    
    // Footer
    about: "من نحن",
    contact: "اتصل بنا",
    terms: "الشروط والأحكام",
    privacy: "سياسة الخصوصية",
    
    // Auth
    loginTitle: "تسجيل الدخول",
    registerTitle: "إنشاء حساب",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    name: "الاسم الكامل",
    confirmPassword: "تأكيد كلمة المرور",
    loginButton: "تسجيل الدخول",
    registerButton: "تسجيل",
    forgotPassword: "نسيت كلمة المرور؟",
    noAccount: "ليس لديك حساب؟",
    hasAccount: "لديك حساب بالفعل؟",
    
    // Cart
    cartTitle: "عربة التسوق",
    emptyCart: "عربة التسوق فارغة",
    continueShopping: "مواصلة التسوق",
    checkout: "إتمام الشراء",
    total: "المجموع",
    remove: "إزالة",
    
    // Product
    addToCart: "إضافة إلى عربة التسوق",
    quantity: "الكمية",
    description: "الوصف",
    specifications: "المواصفات",
    reviews: "التقييمات",
    price: "السعر",
    
    // Location
    currentLocation: "الموقع الحالي",
    updateLocation: "تحديث الموقع",
    locationPermission: "السماح بالوصول إلى الموقع",
    locationDistance: "المسافة",
    
    // Orders
    orders: "الطلبات",
    orderHistory: "سجل الطلبات",
    orderDetails: "تفاصيل الطلب",
    orderDate: "تاريخ الطلب",
    orderStatus: "الحالة",
    orderTotal: "المجموع",
    
    // Misc
    loading: "جاري التحميل...",
    error: "حدث خطأ ما",
    success: "تمت العملية بنجاح!",
    confirm: "تأكيد",
    cancel: "إلغاء",
  }
};

type Language = 'en' | 'ar';
type TranslationKeys = keyof typeof translations.en;

let currentLanguage: Language = 'ar'; // Default to Arabic

export const setLanguage = (lang: Language) => {
  currentLanguage = lang;
};

export const t = (key: TranslationKeys): string => {
  return translations[currentLanguage][key] || key;
};