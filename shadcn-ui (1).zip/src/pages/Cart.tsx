import CartList from '@/components/cart/CartList';

export default function Cart() {
  return <CartList />;
}