import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import CategoryList from '@/components/home/CategoryList';

export default function Categories() {
  const [searchTerm, setSearchTerm] = useState('');
  const { categories } = useStore();
  
  if (!categories) {
    return (
      <div className="container py-10">
        <h1 className="text-2xl font-bold mb-6 text-right">التصنيفات</h1>
        <p className="text-center text-muted-foreground">جاري تحميل التصنيفات...</p>
      </div>
    );
  }
  
  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="container py-10">
      <h1 className="text-2xl font-bold mb-6 text-right">التصنيفات</h1>
      
      <div className="relative mb-6">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input 
          type="search"
          placeholder="البحث في التصنيفات..."
          className="pr-10 text-right"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {filteredCategories.map((category) => (
          <a 
            key={category.id}
            href={`/category/${category.id}`}
            className="group"
          >
            <div className="rounded-lg overflow-hidden border shadow-sm transition-all group-hover:shadow-md">
              <div className="aspect-square">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-3 text-center font-medium">{category.name}</div>
            </div>
          </a>
        ))}
      </div>
      
      {filteredCategories.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">لا توجد نتائج للبحث "{searchTerm}"</p>
        </div>
      )}
    </div>
  );
}