import OrderConfirmation from '@/components/order/OrderConfirmation';

export default function OrderConfirmationPage() {
  return <OrderConfirmation />;
}