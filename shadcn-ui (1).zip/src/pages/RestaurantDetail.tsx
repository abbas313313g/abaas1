import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, Clock, MapPin } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Restaurant, Product } from '@/lib/types';
import { Button } from '@/components/ui/button';
import ProductList from '@/components/home/ProductList';
import { Separator } from '@/components/ui/separator';

export default function RestaurantDetail() {
  const { restaurantId } = useParams();
  const { restaurants, products } = useStore();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [restaurantProducts, setRestaurantProducts] = useState<Product[]>([]);
  const [mapUrl, setMapUrl] = useState<string>('');

  useEffect(() => {
    if (restaurantId) {
      const foundRestaurant = restaurants.find(r => r.id === restaurantId);
      if (foundRestaurant) {
        setRestaurant(foundRestaurant);
        
        // Generate Google Maps URL if location exists
        if (foundRestaurant.location) {
          const { latitude, longitude } = foundRestaurant.location;
          setMapUrl(`https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${latitude},${longitude}&zoom=16`);
        }

        // Filter products for this restaurant
        const relatedProducts = products.filter(p => 
          p.restaurant && p.restaurant.toLowerCase() === foundRestaurant.name.toLowerCase()
        );
        setRestaurantProducts(relatedProducts);
      }
    }
  }, [restaurantId, restaurants, products]);

  if (!restaurant) {
    return (
      <div className="container py-10">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Restaurant not found</h2>
          <Link to="/">
            <Button>Go back to home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-10">
      {/* Restaurant Hero Section */}
      <div className="relative h-60 md:h-80 mb-6">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 p-6 w-full">
          <Link to="/" className="text-white mb-2 flex items-center hover:underline">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to home
          </Link>
          <h1 className="text-3xl font-bold text-white">{restaurant.name}</h1>
        </div>
      </div>

      <div className="container">
        {/* Restaurant Info */}
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <div className="flex items-center">
            <Star className="h-5 w-5 fill-yellow-400 stroke-yellow-400 mr-1" />
            <span className="font-medium">{restaurant.rating} Rating</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-5 w-5 mr-1" />
            <span>{restaurant.deliveryTime} Delivery</span>
          </div>
          {restaurant.location && (
            <div className="flex items-center">
              <MapPin className="h-5 w-5 mr-1 text-primary" />
              <span>View Location</span>
            </div>
          )}
        </div>

        {/* Description */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-2">About {restaurant.name}</h2>
          <p className="text-muted-foreground">
            {restaurant.description || `${restaurant.name} offers a variety of delicious dishes for delivery. Known for quality ingredients and excellent service.`}
          </p>
        </div>

        {/* Map if location exists */}
        {restaurant.location && (
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Location</h2>
            <div className="aspect-[16/9] rounded-lg overflow-hidden border">
              <iframe
                title={`Location of ${restaurant.name}`}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src={mapUrl}
              ></iframe>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Coordinates: {restaurant.location.latitude}, {restaurant.location.longitude}
            </p>
          </div>
        )}

        <Separator className="my-6" />

        {/* Restaurant Products */}
        {restaurantProducts.length > 0 ? (
          <div>
            <h2 className="text-xl font-bold mb-4">Menu from {restaurant.name}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {restaurantProducts.map((product) => (
                <Link 
                  to={`/product/${product.id}`} 
                  key={product.id} 
                  className="group"
                >
                  <div className="rounded-lg overflow-hidden border shadow-sm transition-all group-hover:shadow-md h-full flex flex-col">
                    <div className="aspect-square">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-3 flex flex-col flex-grow">
                      <h3 className="font-medium text-sm mb-1 line-clamp-2">
                        {product.name}
                        {product.location && (
                          <MapPin className="inline-block h-3 w-3 ml-1 text-primary" title="Location Available" />
                        )}
                      </h3>
                      <div className="flex items-center justify-between mt-auto">
                        <span className="font-bold text-primary">{new Intl.NumberFormat('ar-IQ', {
                          style: 'decimal',
                          maximumFractionDigits: 0,
                        }).format(product.price)} د.ع</span>
                        <Button 
                          size="sm" 
                          variant="secondary"
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-muted-foreground">No products available from this restaurant yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}