import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProductsByCategory } from '@/lib/data';
import { Product } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { useStore } from '@/lib/store';

export default function CategoryDetail() {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { categories } = useStore();
  const [category, setCategory] = useState(categories?.[0]);
  
  useEffect(() => {
    if (categoryId && categories) {
      const foundCategory = categories.find(c => c.id === categoryId);
      
      if (foundCategory) {
        setCategory(foundCategory);
        const categoryProducts = getProductsByCategory(foundCategory.name);
        setProducts(categoryProducts);
      }
    }
  }, [categoryId, categories]);
  
  if (!category) {
    return (
      <div className="container py-10 text-center">
        <p className="text-muted-foreground">تصنيف غير موجود</p>
        <Link to="/categories" className="mt-4 inline-block">
          <Button>العودة إلى التصنيفات</Button>
        </Link>
      </div>
    );
  }

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (product.restaurant && product.restaurant.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  return (
    <div className="container py-10">
      <div className="flex items-center gap-2 mb-6">
        <Link to="/categories">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">{category.name}</h1>
      </div>
      
      <div className="relative mb-6">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input 
          type="search"
          placeholder={`البحث في ${category.name}...`}
          className="pr-10 text-right"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredProducts.map((product) => (
            <Link 
              key={product.id} 
              to={`/product/${product.id}`}
              className="group"
            >
              <div className="rounded-lg overflow-hidden border shadow-sm transition-all group-hover:shadow-md h-full flex flex-col">
                <div className="aspect-square">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3 flex flex-col flex-grow">
                  <h3 className="font-medium text-sm mb-1 line-clamp-2 text-right">{product.name}</h3>
                  {product.restaurant && (
                    <p className="text-xs text-muted-foreground mb-2 text-right">{product.restaurant}</p>
                  )}
                  <div className="mt-auto">
                    <p className="font-bold text-primary text-right">
                      {new Intl.NumberFormat('ar-IQ', {
                        style: 'decimal',
                        maximumFractionDigits: 0,
                      }).format(product.price)} د.ع
                    </p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground">لا توجد منتجات في هذا التصنيف</p>
          {searchTerm && (
            <p className="text-sm mt-2">حاول تعديل بحثك عن "{searchTerm}"</p>
          )}
        </div>
      )}
    </div>
  );
}