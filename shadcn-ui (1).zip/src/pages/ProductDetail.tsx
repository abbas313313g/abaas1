import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products, getProductsByCategory } from '@/lib/data';
import { Product } from '@/lib/types';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Minus, Plus, ShoppingCart } from 'lucide-react';

export default function ProductDetail() {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const { addToCart } = useStore();
  
  useEffect(() => {
    if (productId) {
      const foundProduct = products.find(p => p.id === productId);
      if (foundProduct) {
        setProduct(foundProduct);
        
        // Get related products from same category
        const related = getProductsByCategory(foundProduct.category)
          .filter(p => p.id !== foundProduct.id)
          .slice(0, 5);
        setRelatedProducts(related);
      }
    }
  }, [productId]);
  
  if (!product) {
    return (
      <div className="container py-10 text-center">
        <p>Product not found</p>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(price);
  };
  
  return (
    <div className="container py-10">
      <Link to={`/categories/${product.category.toLowerCase()}`} className="inline-flex items-center mb-6">
        <Button variant="ghost" size="sm" className="gap-1">
          <ArrowLeft className="h-4 w-4" />
          Back to {product.category}
        </Button>
      </Link>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <Card className="overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full aspect-square object-cover"
            />
          </Card>
        </div>
        
        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          
          {product.restaurant && (
            <Link to={`/restaurants/${product.restaurant.toLowerCase().replace(/\s+/g, '-')}`}>
              <p className="text-primary font-medium mb-4">{product.restaurant}</p>
            </Link>
          )}
          
          <p className="text-muted-foreground mb-6">{product.description}</p>
          
          <p className="text-3xl font-bold text-primary mb-6">{formatPrice(product.price)} د.ع</p>
          
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center border rounded-md">
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-none"
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                disabled={quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-10 text-center">{quantity}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-none"
                onClick={() => setQuantity(q => q + 1)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <Button 
              className="flex-1"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
            </Button>
          </div>
          
          <div className="border-t pt-6 mt-6">
            <p className="font-medium mb-2">Category: {product.category}</p>
            {product.location && (
              <div className="mt-4">
                <h3 className="font-medium mb-2">Location</h3>
                <div className="aspect-video rounded-lg overflow-hidden border">
                  <iframe 
                    width="100%" 
                    height="100%" 
                    frameBorder="0" 
                    scrolling="no" 
                    marginHeight={0} 
                    marginWidth={0} 
                    src={`https://maps.google.com/maps?q=${product.location.latitude},${product.location.longitude}&z=15&output=embed`} 
                    title={`${product.name} location`}
                  ></iframe>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  Coordinates: {product.location.latitude}, {product.location.longitude}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {relatedProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Related Products</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {relatedProducts.map((relatedProduct) => (
              <Link 
                key={relatedProduct.id}
                to={`/product/${relatedProduct.id}`}
                className="group"
              >
                <div className="rounded-lg overflow-hidden border shadow-sm transition-all group-hover:shadow-md h-full flex flex-col">
                  <div className="aspect-square">
                    <img
                      src={relatedProduct.image}
                      alt={relatedProduct.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-3 flex flex-col flex-grow">
                    <h3 className="font-medium text-sm mb-1 line-clamp-2">{relatedProduct.name}</h3>
                    <div className="mt-auto">
                      <p className="font-bold text-primary">{formatPrice(relatedProduct.price)} د.ع</p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}