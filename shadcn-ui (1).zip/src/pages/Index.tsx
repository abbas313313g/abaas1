import BannerCarousel from '@/components/home/BannerCarousel';
import CategoryList from '@/components/home/CategoryList';
import RestaurantList from '@/components/home/RestaurantList';
import ProductList from '@/components/home/ProductList';
import { useStore } from '@/lib/store';
import { useEffect } from 'react';

export default function Index() {
  const { currentLocation, isAuthenticated } = useStore();

  // Display location prompt for users without a location set
  useEffect(() => {
    if (isAuthenticated && !currentLocation) {
      const timer = setTimeout(() => {
        const userConsent = window.confirm('نحتاج إلى موقعك لتقديم خدمة أفضل. هل تريد تحديد موقعك الآن؟');
        if (userConsent) {
          window.location.href = '/profile?tab=location';
        }
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [currentLocation, isAuthenticated]);

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-grow">
        {/* Banner Carousel */}
        <BannerCarousel />
        
        {/* Categories */}
        <CategoryList />
        
        {/* Featured Restaurants */}
        <section className="py-8 bg-gray-50">
          <div className="container">
            <h2 className="text-2xl font-bold mb-6 text-right">المطاعم المميزة</h2>
            <RestaurantList />
          </div>
        </section>
        
        {/* Popular Products */}
        <section className="py-8">
          <div className="container">
            <h2 className="text-2xl font-bold mb-6 text-right">المنتجات الشائعة</h2>
            <ProductList />
          </div>
        </section>
      </main>
    </div>
  );
}