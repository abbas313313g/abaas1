import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import ProfileInfo from '@/components/profile/ProfileInfo';
import { UserCircle, MapPin, ShoppingBag } from 'lucide-react';
import LocationPicker from '@/components/location/LocationPicker';

export default function Profile() {
  const navigate = useNavigate();
  const { isAuthenticated } = useStore();
  const [activeTab, setActiveTab] = useState("account");

  if (!isAuthenticated) {
    navigate('/auth');
    return null;
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6 text-right">الملف الشخصي</h1>
      
      <Tabs 
        defaultValue="account" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <div className="flex justify-end mb-6">
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="orders">
              <ShoppingBag className="h-4 w-4 mr-2" />
              طلباتي
            </TabsTrigger>
            <TabsTrigger value="location">
              <MapPin className="h-4 w-4 mr-2" />
              موقعي
            </TabsTrigger>
            <TabsTrigger value="account">
              <UserCircle className="h-4 w-4 mr-2" />
              حسابي
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="account">
          <ProfileInfo />
        </TabsContent>
        
        <TabsContent value="location">
          <div className="max-w-md mx-auto">
            <LocationPicker />
          </div>
        </TabsContent>
        
        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle className="text-right">طلباتي</CardTitle>
              <CardDescription className="text-right">عرض جميع طلباتك السابقة.</CardDescription>
            </CardHeader>
            <CardContent className="text-right">
              <p className="text-muted-foreground">لا توجد طلبات سابقة.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}