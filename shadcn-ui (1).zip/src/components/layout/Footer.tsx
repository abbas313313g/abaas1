import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t mt-auto">
      <div className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Links */}
          <div className="text-right">
            <h3 className="font-bold text-lg mb-3">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-muted-foreground hover:text-primary transition-colors">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link to="/categories" className="text-muted-foreground hover:text-primary transition-colors">
                  التصنيفات
                </Link>
              </li>
              <li>
                <Link to="/profile" className="text-muted-foreground hover:text-primary transition-colors">
                  الحساب الشخصي
                </Link>
              </li>
              <li>
                <Link to="/cart" className="text-muted-foreground hover:text-primary transition-colors">
                  سلة التسوق
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div className="text-right">
            <h3 className="font-bold text-lg mb-3">تواصل معنا</h3>
            <address className="not-italic text-muted-foreground">
              <p>العراق، بغداد</p>
              <p className="mt-2">هاتف: 07XXXXXXXXX</p>
              <p>البريد الإلكتروني: info@easyshop.com</p>
            </address>
          </div>
          
          {/* About */}
          <div className="text-right">
            <h3 className="font-bold text-lg mb-3">عن متجر سهل</h3>
            <p className="text-muted-foreground">
              متجر سهل هو منصة تسوق إلكتروني عراقية توفر أفضل المنتجات بأسعار مناسبة مع خدمة توصيل سريعة وموثوقة.
            </p>
          </div>
        </div>
        
        <div className="border-t mt-6 pt-6 flex flex-col md:flex-row items-center justify-between">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} متجر سهل. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}