import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, User, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";

export default function Header() {
  const location = useLocation();
  const { cart, isAuthenticated, currentLocation } = useStore();
  
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  
  return (
    <header className="border-b sticky top-0 z-10 bg-white">
      <div className="container py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="font-bold text-xl text-primary">
            متجر سهل
          </Link>
          
          {/* Navigation Links */}
          <div className="hidden md:flex space-x-1 space-x-reverse">
            <Link to="/">
              <Button variant={location.pathname === "/" ? "secondary" : "ghost"}>
                الرئيسية
              </Button>
            </Link>
            <Link to="/categories">
              <Button variant={location.pathname === "/categories" ? "secondary" : "ghost"}>
                التصنيفات
              </Button>
            </Link>
          </div>
          
          {/* Location and User Controls */}
          <div className="flex items-center space-x-4 space-x-reverse">
            {/* Location indicator */}
            <Link to="/profile?tab=location">
              <Button variant="ghost" size="sm" className="relative">
                <MapPin className={currentLocation ? "text-primary" : ""} />
                {!currentLocation && (
                  <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
                )}
              </Button>
            </Link>
            
            {/* User profile or login button */}
            <Link to={isAuthenticated ? "/profile" : "/auth"}>
              <Button variant="ghost" size="sm">
                <User />
              </Button>
            </Link>
            
            {/* Shopping cart */}
            <Link to="/cart">
              <Button variant="ghost" size="sm" className="relative">
                <ShoppingCart />
                {totalItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center">
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}