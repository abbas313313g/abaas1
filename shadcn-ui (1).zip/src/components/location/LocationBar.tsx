import { useEffect, useState } from 'react';
import { MapPin, Loader2 } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { t } from '@/lib/i18n';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function LocationBar() {
  const { currentLocation, trackUserLocation } = useStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleUpdateLocation = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await trackUserLocation();
    } catch (err) {
      setError('فشل تحديث الموقع. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-accent p-3 rounded-lg mb-6 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
          <div>
            {currentLocation ? (
              <p className="text-sm font-medium truncate max-w-[220px] md:max-w-[300px]">
                {currentLocation.address}
              </p>
            ) : (
              <p className="text-sm font-medium">{t('updateLocation')}</p>
            )}
          </div>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handleUpdateLocation}
          disabled={isLoading}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            t('updateLocation')
          )}
        </Button>
      </div>
      
      {error && (
        <Alert variant="destructive" className="mt-2">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}