import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Loader2 } from 'lucide-react';
import { getUserLocation, getAddressFromCoordinates } from '@/lib/location';
import { useStore } from '@/lib/store';
import { useToast } from '@/components/ui/use-toast';

export default function LocationPicker() {
  const { currentLocation, setCurrentLocation } = useStore();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState(currentLocation?.address || '');
  const { toast } = useToast();

  const detectLocation = async () => {
    try {
      setLoading(true);
      const coords = await getUserLocation();
      const addressText = await getAddressFromCoordinates(coords.latitude, coords.longitude);
      
      setAddress(addressText);
      setCurrentLocation({
        latitude: coords.latitude,
        longitude: coords.longitude,
        address: addressText
      });
      
      toast({
        title: "تم تحديد موقعك بنجاح",
        description: addressText,
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "خطأ في تحديد الموقع",
        description: "يرجى السماح للمتصفح بالوصول إلى موقعك أو أدخل العنوان يدويًا."
      });
    } finally {
      setLoading(false);
    }
  };

  const saveManualAddress = () => {
    if (!address.trim()) {
      toast({
        variant: "destructive",
        title: "العنوان مطلوب",
        description: "يرجى إدخال عنوانك"
      });
      return;
    }

    // For manual address entry, we use placeholder coordinates
    // In a real app, you would use a geocoding service here
    setCurrentLocation({
      latitude: currentLocation?.latitude || 33.312805,
      longitude: currentLocation?.longitude || 44.361488,
      address: address
    });

    toast({
      title: "تم حفظ العنوان",
      description: "تم تعيين عنوان التوصيل الخاص بك"
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-right">تحديد الموقع</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-right block text-sm font-medium">عنوان التوصيل</label>
          <Input 
            value={address} 
            onChange={(e) => setAddress(e.target.value)}
            placeholder="أدخل عنوانك للتوصيل"
            className="text-right"
            dir="rtl"
          />
        </div>
        
        {currentLocation && (
          <div className="rounded-md bg-slate-50 p-3 text-right">
            <div className="flex items-center justify-end gap-2 text-primary">
              <span>الموقع الحالي</span>
              <MapPin className="h-4 w-4" />
            </div>
            <p className="text-sm text-muted-foreground mt-1">{currentLocation.address}</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col gap-2 items-stretch">
        <Button 
          className="w-full"
          onClick={detectLocation}
          disabled={loading}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              جاري التحميل...
            </>
          ) : (
            <>
              <MapPin className="mr-2 h-4 w-4" />
              تحديد موقعي الحالي
            </>
          )}
        </Button>
        <Button 
          variant="outline" 
          className="w-full"
          onClick={saveManualAddress}
        >
          حفظ العنوان المدخل
        </Button>
      </CardFooter>
    </Card>
  );
}