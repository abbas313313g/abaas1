import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { MapPin, Phone, User } from 'lucide-react';
import { useStore } from '@/lib/store';
import { v4 as uuidv4 } from 'uuid';

export default function AuthForm() {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useStore();
  const [activeTab, setActiveTab] = useState<string>("login");
  
  // Login form state
  const [loginPhone, setLoginPhone] = useState<string>("");
  
  // Register form state
  const [name, setName] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [location, setLocation] = useState<string>("");
  const [locationCoords, setLocationCoords] = useState<{latitude: number; longitude: number} | null>(null);
  
  // If user is already authenticated, redirect to home page
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocationCoords({ latitude, longitude });
          setLocation("Your location has been captured");
          
          // You could use a reverse geocoding API to get a human-readable address
          // but for simplicity we'll just use coordinates
        },
        (error) => {
          console.error("Error getting location:", error);
          setLocation("Failed to get your location");
        }
      );
    } else {
      setLocation("Geolocation is not supported by your browser");
    }
  };
  
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if there's a user with this phone number in localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find((u: any) => u.phone === loginPhone);
    
    if (user) {
      login(user);
      navigate('/');
    } else {
      alert("No account found with this phone number. Please register first.");
      setActiveTab("register");
    }
  };
  
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !phone || !locationCoords) {
      alert("Please fill all fields and allow location access");
      return;
    }
    
    // Create new user object
    const newUser = {
      id: uuidv4(),
      name,
      phone,
      location: {
        address: location,
        latitude: locationCoords.latitude,
        longitude: locationCoords.longitude
      }
    };
    
    // Add to localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // Log in the new user
    login(newUser);
    navigate('/');
  };
  
  return (
    <div className="container py-10 max-w-md mx-auto">
      <Card>
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl text-center">Welcome to EasyShop</CardTitle>
          <CardDescription className="text-center">
            Login or create an account to continue
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="phone"
                      type="tel" 
                      placeholder="Enter your phone number" 
                      className="pl-10"
                      value={loginPhone}
                      onChange={(e) => setLoginPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <Button type="submit" className="w-full">Login</Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="name"
                      placeholder="Enter your full name" 
                      className="pl-10"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="registerPhone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="registerPhone"
                      type="tel" 
                      placeholder="Enter your phone number" 
                      className="pl-10"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="location"
                      placeholder="Your location" 
                      className="pl-10"
                      value={location}
                      readOnly
                      required
                    />
                  </div>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={handleGetLocation}
                    className="w-full"
                  >
                    Get My Location
                  </Button>
                </div>
                
                <Button type="submit" className="w-full">Register</Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}