import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useStore } from '@/lib/store';
import { MapPin } from 'lucide-react';
import { formatPrice } from '@/lib/utils';

export default function ProductList() {
  const { products, addToCart } = useStore();
  
  if (!products || products.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">لا توجد منتجات متاحة</p>
      </div>
    );
  }
  
  // Show only the first 8 products for the homepage
  const displayProducts = products.slice(0, 8);
  
  const handleAddToCart = (event: React.MouseEvent, productId: string) => {
    event.preventDefault();
    event.stopPropagation();
    
    const product = products.find(p => p.id === productId);
    if (product) {
      addToCart(product);
    }
  };
  
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {displayProducts.map((product) => (
        <Link 
          to={`/product/${product.id}`} 
          key={product.id} 
          className="group"
        >
          <div className="rounded-lg overflow-hidden border shadow-sm transition-all group-hover:shadow-md h-full flex flex-col">
            <div className="aspect-square relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {product.discount > 0 && (
                <span className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  خصم {product.discount}%
                </span>
              )}
            </div>
            <div className="p-3 flex flex-col flex-grow">
              <h3 className="font-medium text-sm mb-1 text-right">
                {product.name}
                {product.location && (
                  <MapPin className="inline-block h-3 w-3 mr-1 text-primary" title="الموقع متاح" />
                )}
              </h3>
              <p className="text-muted-foreground text-xs mb-3 text-right line-clamp-2">
                {product.description}
              </p>
              <div className="flex items-center justify-between mt-auto">
                <div className="flex flex-col">
                  {product.discount > 0 && (
                    <span className="text-xs text-muted-foreground line-through">
                      {formatPrice(Math.round(product.price / (1 - product.discount / 100)))} د.ع
                    </span>
                  )}
                  <span className="font-bold text-primary">{formatPrice(product.price)} د.ع</span>
                </div>
                <Button 
                  size="sm" 
                  onClick={(e) => handleAddToCart(e, product.id)}
                >
                  إضافة
                </Button>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}