import { Link } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { useStore } from '@/lib/store';
import { Star, Clock, MapPin } from 'lucide-react';
import { calculateDistance } from '@/lib/store';

export default function RestaurantList() {
  const { restaurants, currentLocation } = useStore();
  
  if (!restaurants || restaurants.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">لا توجد مطاعم متاحة</p>
      </div>
    );
  }
  
  // Calculate distance if user location is available
  const restaurantsWithDistance = restaurants.map(restaurant => {
    if (currentLocation && restaurant.location) {
      const distance = calculateDistance(
        currentLocation.latitude,
        currentLocation.longitude,
        restaurant.location.latitude,
        restaurant.location.longitude
      );
      return { ...restaurant, distance };
    }
    return restaurant;
  });
  
  // Sort by distance if available
  const sortedRestaurants = currentLocation 
    ? restaurantsWithDistance
        .filter(r => r.hasOwnProperty('distance'))
        .sort((a, b) => (a.distance || 0) - (b.distance || 0))
        .concat(restaurantsWithDistance.filter(r => !r.hasOwnProperty('distance')))
    : restaurantsWithDistance;
  
  // Show only first 6 restaurants
  const displayRestaurants = sortedRestaurants.slice(0, 6);
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {displayRestaurants.map((restaurant) => (
        <Link 
          to={`/restaurant/${restaurant.id}`} 
          key={restaurant.id}
        >
          <Card className="overflow-hidden h-full transition-all hover:shadow-md">
            <div className="aspect-video relative">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 right-0 bg-white px-2 py-1 m-2 rounded-md text-xs font-medium flex items-center">
                <Clock className="h-3 w-3 ml-1" />
                {restaurant.deliveryTime}
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-yellow-400 stroke-yellow-400" />
                  <span className="text-sm mr-1">{restaurant.rating}</span>
                </div>
                <h3 className="font-bold text-right text-lg">{restaurant.name}</h3>
              </div>
              
              <div className="flex justify-between items-center mt-2">
                {restaurant.distance !== undefined ? (
                  <span className="text-xs text-muted-foreground">
                    {restaurant.distance.toFixed(1)} كم
                  </span>
                ) : (
                  <span />
                )}
                
                {restaurant.location && (
                  <div className="flex items-center text-primary text-sm">
                    <span className="ml-1">عرض الموقع</span>
                    <MapPin className="h-4 w-4" />
                  </div>
                )}
              </div>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}