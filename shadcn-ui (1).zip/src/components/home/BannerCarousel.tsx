import { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
}

const banners: Banner[] = [
  {
    id: '1',
    image: '/assets/banners/banner1.jpg',
    title: 'عروض رمضان',
    subtitle: 'خصومات تصل إلى ٥٠٪ على جميع المنتجات'
  },
  {
    id: '2',
    image: '/assets/banners/banner2.jpg',
    title: 'وجبات جاهزة',
    subtitle: 'توصيل سريع خلال ٣٠ دقيقة'
  },
  {
    id: '3',
    image: '/assets/banners/banner3.jpg',
    title: 'منتجات طازجة',
    subtitle: 'من المزرعة إلى منزلك مباشرة'
  }
];

export default function BannerCarousel() {
  const [current, setCurrent] = useState(0);
  const totalSlides = banners.length;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev === totalSlides - 1 ? 0 : prev + 1));
    }, 5000);
    
    return () => clearInterval(timer);
  }, [totalSlides]);

  const next = () => {
    setCurrent((prev) => (prev === totalSlides - 1 ? 0 : prev + 1));
  };

  const prev = () => {
    setCurrent((prev) => (prev === 0 ? totalSlides - 1 : prev - 1));
  };

  return (
    <div className="relative overflow-hidden rounded-lg h-[300px] md:h-[400px]">
      {/* Slides */}
      <div 
        className="flex transition-transform duration-500 h-full" 
        style={{ transform: `translateX(${current * 100}%)` }}
      >
        {banners.map((banner, index) => (
          <div 
            key={banner.id} 
            className="absolute w-full h-full flex-shrink-0"
            style={{ right: `${index * 100}%` }}
          >
            <img 
              src={banner.image} 
              alt={banner.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex flex-col items-end justify-center p-8 text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-2 text-right">{banner.title}</h2>
              <p className="text-xl md:text-2xl max-w-md text-right">{banner.subtitle}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Navigation buttons */}
      <div className="absolute inset-0 flex items-center justify-between p-4">
        <Button 
          size="icon" 
          variant="outline" 
          className="bg-white/80 hover:bg-white"
          onClick={prev}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <Button 
          size="icon" 
          variant="outline"
          className="bg-white/80 hover:bg-white"
          onClick={next}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>
      
      {/* Indicators */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
        {banners.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-colors ${
              current === index ? 'bg-primary' : 'bg-white/50'
            }`}
            onClick={() => setCurrent(index)}
          />
        ))}
      </div>
    </div>
  );
}