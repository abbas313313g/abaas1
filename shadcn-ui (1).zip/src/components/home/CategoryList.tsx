import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { useStore } from '@/lib/store';

export default function CategoryList() {
  const { categories } = useStore();

  if (!categories || categories.length === 0) {
    return (
      <section className="py-8">
        <div className="container">
          <h2 className="text-2xl font-bold mb-6 text-right">التصنيفات</h2>
          <p className="text-center text-muted-foreground">لا توجد تصنيفات متاحة</p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-8">
      <div className="container">
        <h2 className="text-2xl font-bold mb-6 text-right">التصنيفات</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link to={`/category/${category.id}`} key={category.id}>
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <div className="aspect-square relative">
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-3">
                    <h3 className="text-white font-medium text-center w-full text-lg">
                      {category.name}
                    </h3>
                  </div>
                </div>
                <CardContent className="p-3 text-center">
                  <p className="text-muted-foreground text-sm">
                    {category.productCount} منتج
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}