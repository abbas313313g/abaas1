import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { useStore } from '@/lib/store';
import { v4 as uuidv4 } from 'uuid';

export default function CartList() {
  const navigate = useNavigate();
  const { 
    cart, 
    removeFromCart, 
    updateCartItemQuantity, 
    clearCart, 
    user, 
    isAuthenticated,
    currentLocation 
  } = useStore();
  const [distance, setDistance] = useState<number>(0);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(price);
  };
  
  const calculateDeliveryFee = (distance: number) => {
    // 1000 dinars per kilometer
    return Math.ceil(distance) * 1000;
  };
  
  const subtotal = cart.reduce((total, item) => total + item.product.price * item.quantity, 0);
  const deliveryFee = calculateDeliveryFee(distance);
  const total = subtotal + deliveryFee;
  
  // Calculate distance if user has location
  useEffect(() => {
    if (user?.location && currentLocation) {
      const dist = calculateDistance(
        user.location.latitude,
        user.location.longitude,
        currentLocation.latitude,
        currentLocation.longitude
      );
      setDistance(dist);
    } else if (user?.location) {
      // Use random distance between 1-10 km for demo purposes if no current location
      setDistance(Math.random() * 9 + 1);
    }
  }, [user, currentLocation]);
  
  const calculateDistance = (
    lat1: number, 
    lon1: number, 
    lat2: number, 
    lon2: number
  ): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distance in km
    return distance;
  };
  
  const deg2rad = (deg: number): number => {
    return deg * (Math.PI/180);
  };
  
  const handleCheckout = async () => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    
    // Create order
    const order = {
      id: uuidv4(),
      userId: user!.id,
      items: [...cart],
      totalPrice: total,
      deliveryFee,
      distance,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    
    // Save order to localStorage
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    // Clear cart
    clearCart();
    
    try {
      // Import dynamically to avoid circular dependencies
      const { sendTelegramMessage, formatOrderForTelegram } = await import('@/lib/telegramBot');
      // Send order to Telegram
      const telegramMessage = formatOrderForTelegram(order, user);
      await sendTelegramMessage(telegramMessage);
    } catch (error) {
      console.error("Failed to send order to Telegram:", error);
      // Continue with checkout even if Telegram notification fails
    }
    
    // Navigate to confirmation page
    navigate('/order-confirmation', { state: { order } });
  };
  
  if (cart.length === 0) {
    return (
      <div className="container py-10 text-center">
        <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
        <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/categories">
          <Button>Browse Products</Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="container py-10">
      <h1 className="text-2xl font-bold mb-6">Shopping Cart</h1>
      
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          {cart.map((item) => (
            <div key={item.product.id} className="flex gap-4 items-start pb-4 border-b">
              <div className="w-24 h-24 flex-shrink-0">
                <img 
                  src={item.product.image} 
                  alt={item.product.name} 
                  className="w-full h-full object-cover rounded-md"
                />
              </div>
              
              <div className="flex-1">
                <h3 className="font-medium">{item.product.name}</h3>
                {item.product.restaurant && (
                  <p className="text-sm text-muted-foreground">{item.product.restaurant}</p>
                )}
                <p className="font-bold mt-1">{formatPrice(item.product.price)} د.ع</p>
              </div>
              
              <div className="flex items-center border rounded-md">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-none"
                  onClick={() => updateCartItemQuantity(item.product.id, item.quantity - 1)}
                  disabled={item.quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-8 text-center">{item.quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-none"
                  onClick={() => updateCartItemQuantity(item.product.id, item.quantity + 1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              <Button
                variant="ghost"
                size="icon"
                className="text-red-500 hover:text-red-600"
                onClick={() => removeFromCart(item.product.id)}
              >
                <Trash2 className="h-5 w-5" />
              </Button>
            </div>
          ))}
        </div>
        
        <div>
          <div className="border rounded-lg p-4 shadow-sm bg-background sticky top-20">
            <h2 className="text-lg font-bold mb-4">Order Summary</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal)} د.ع</span>
              </div>
              
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>{formatPrice(deliveryFee)} د.ع</span>
              </div>
              
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Distance</span>
                <span>{distance.toFixed(1)} km</span>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>{formatPrice(total)} د.ع</span>
              </div>
              
              <Button 
                className="w-full mt-4" 
                onClick={handleCheckout}
              >
                Checkout <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              
              {!isAuthenticated && (
                <p className="text-sm text-muted-foreground text-center mt-2">
                  Please <Link to="/auth" className="underline text-primary">login</Link> to checkout
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}