import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/lib/store';
import { MapPin, Phone, User, LogOut } from 'lucide-react';

export default function ProfileInfo() {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useStore();
  
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [location, setLocation] = useState(user?.location?.address || '');
  const [editMode, setEditMode] = useState(false);
  
  if (!user) {
    navigate('/auth');
    return null;
  }
  
  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation("Your location has been captured");
          
          // Update location in form state
          updateUser({
            location: {
              address: "Your location has been captured",
              latitude,
              longitude
            }
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          setLocation("Failed to get your location");
        }
      );
    } else {
      setLocation("Geolocation is not supported by your browser");
    }
  };
  
  const handleSaveChanges = () => {
    // Update user in store and localStorage
    const updatedUser = {
      ...user,
      name,
      phone,
    };
    
    // Update user in localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map((u: any) => u.id === user.id ? updatedUser : u);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    
    // Update user in store
    updateUser(updatedUser);
    
    setEditMode(false);
  };
  
  const handleLogout = () => {
    logout();
    navigate('/auth');
  };
  
  const orders = JSON.parse(localStorage.getItem('orders') || '[]')
    .filter((order: any) => order.userId === user.id)
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(price);
  };
  
  return (
    <div className="container py-10">
      <div className="max-w-3xl mx-auto">
        <Tabs defaultValue="profile">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="orders">Order History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile">
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>My Profile</CardTitle>
                <CardDescription>
                  Manage your account details
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {editMode ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="phone"
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="location"
                          value={location}
                          readOnly
                          className="pl-10"
                        />
                      </div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={handleGetLocation}
                        className="w-full"
                      >
                        Update My Location
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 pb-2 border-b">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Full Name</p>
                        <p className="font-medium">{user.name}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 pb-2 border-b">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Phone Number</p>
                        <p className="font-medium">{user.phone}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 pb-2 border-b">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Location</p>
                        <p className="font-medium">{user.location?.address || 'No location set'}</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                {editMode ? (
                  <>
                    <Button variant="outline" onClick={() => setEditMode(false)}>Cancel</Button>
                    <Button onClick={handleSaveChanges}>Save Changes</Button>
                  </>
                ) : (
                  <>
                    <Button variant="outline" className="flex gap-2" onClick={handleLogout}>
                      <LogOut className="h-4 w-4" />
                      Logout
                    </Button>
                    <Button onClick={() => setEditMode(true)}>Edit Profile</Button>
                  </>
                )}
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="orders">
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Order History</CardTitle>
                <CardDescription>
                  View your previous orders
                </CardDescription>
              </CardHeader>
              <CardContent>
                {orders.length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">You haven't placed any orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order: any) => (
                      <Card key={order.id}>
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-center">
                            <div>
                              <CardTitle className="text-base">Order #{order.id.slice(0, 8)}</CardTitle>
                              <CardDescription>
                                {new Date(order.createdAt).toLocaleDateString()} 
                                {" "}
                                {new Date(order.createdAt).toLocaleTimeString()}
                              </CardDescription>
                            </div>
                            <div className="text-right">
                              <span className={`text-xs px-2 py-1 rounded-full ${
                                order.status === 'pending' 
                                  ? 'bg-yellow-100 text-yellow-800' 
                                  : order.status === 'delivered' 
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}>
                                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                              </span>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="space-y-2">
                            {order.items.map((item: any) => (
                              <div key={item.product.id} className="flex justify-between text-sm">
                                <span>{item.quantity} × {item.product.name}</span>
                                <span>{formatPrice(item.product.price * item.quantity)} د.ع</span>
                              </div>
                            ))}
                            <div className="border-t pt-2 mt-2 flex justify-between font-medium">
                              <span>Delivery Fee</span>
                              <span>{formatPrice(order.deliveryFee)} د.ع</span>
                            </div>
                            <div className="flex justify-between font-bold">
                              <span>Total</span>
                              <span>{formatPrice(order.totalPrice)} د.ع</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}