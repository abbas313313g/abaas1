import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle2, Send } from 'lucide-react';
import { useStore } from '@/lib/store';
import { sendTelegramMessage, formatOrderForTelegram } from '@/lib/telegramBot';

export default function OrderConfirmation() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user } = useStore();
  const order = location.state?.order;
  const [telegramSent, setTelegramSent] = useState<boolean | null>(null);
  
  useEffect(() => {
    if (!isAuthenticated || !order) {
      navigate('/');
    }
  }, [isAuthenticated, order, navigate]);

  // Try to resend if needed
  const handleResendToTelegram = async () => {
    if (!order || !user) return;
    
    try {
      const telegramMessage = formatOrderForTelegram(order, user);
      const success = await sendTelegramMessage(telegramMessage);
      setTelegramSent(success);
    } catch (error) {
      console.error("Failed to send to Telegram:", error);
      setTelegramSent(false);
    }
  };
  
  if (!order) return null;
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-IQ', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };
  
  return (
    <div className="container py-10 max-w-md mx-auto">
      <Card className="border-green-200">
        <CardHeader className="text-center pb-4">
          <CheckCircle2 className="mx-auto h-16 w-16 text-green-500 mb-2" />
          <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Order Number</p>
            <p className="font-medium">#{order.id.slice(0, 8)}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Date & Time</p>
            <p className="font-medium">{formatDate(order.createdAt)}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Customer</p>
            <p className="font-medium">{user?.name}</p>
            <p className="text-sm">{user?.phone}</p>
          </div>
          
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Delivery Location</p>
            <p className="font-medium">{user?.location?.address || 'Your saved location'}</p>
          </div>
          
          <div className="space-y-1 border-t pt-3 mt-3">
            <p className="text-sm text-muted-foreground">Order Summary</p>
            {order.items.map((item: any) => (
              <div key={item.product.id} className="flex justify-between text-sm">
                <span>{item.quantity} × {item.product.name}</span>
                <span>{formatPrice(item.product.price * item.quantity)} د.ع</span>
              </div>
            ))}
          </div>
          
          <div className="border-t pt-3 mt-3 space-y-2">
            <div className="flex justify-between">
              <span>Delivery Fee ({order.distance.toFixed(1)} km)</span>
              <span>{formatPrice(order.deliveryFee)} د.ع</span>
            </div>
            
            <div className="flex justify-between font-bold">
              <span>Total</span>
              <span>{formatPrice(order.totalPrice)} د.ع</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex gap-2 flex-col">
          {telegramSent === false && (
            <Button 
              variant="secondary"
              className="w-full flex items-center gap-2" 
              onClick={handleResendToTelegram}
            >
              <Send className="h-4 w-4" />
              إعادة إرسال الطلب للإدارة
            </Button>
          )}
          <Button 
            className="w-full" 
            onClick={() => navigate('/')}
          >
            مواصلة التسوق
          </Button>
          <Button 
            variant="outline" 
            className="w-full" 
            onClick={() => navigate('/profile')}
          >
            عرض سجل الطلبات
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}